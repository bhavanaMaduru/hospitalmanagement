package com.hospitalmanagement.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="appointment")
public class Appointment {

	@Id
	@GeneratedValue
	@Column(name="AP_ID ")
	private int ap_id ;
	
	@Column(name="P_ID ")
	private int p_id;
	@Column(name="P_ANAME")
	private String p_aname;
	@Column(name="P_AMID ")
	private String p_amid;
	@Column(name="CITY  ")
	private String city;
	@Column(name="GENDER  ")
	private String gender;
	@Column(name=" D_ID")
	private int d_id;
	@Column(name="AP_DATE ")
	@Temporal(TemporalType. DATE)
	private Date ap_date  ;
	@Column(name="AP_TIME ")
	private String ap_time ;
	@Column(name="AP_STATUS ")
	private String status ;
	
	
	
	

	public Appointment(int p_id, String p_aname,String p_amid,String city,String gender,int d_id,int ap_id, Date ap_date,String ap_time,String ap_status ) {
		super();
		this.p_id = p_id;
		this.p_aname = p_aname;
		this.p_amid = p_amid;
		this.city = city;
		this.gender = gender;
		this.d_id = d_id;
		this.ap_id = ap_id;
		this.ap_date=ap_date ;
		this.ap_time = ap_time;
		this.ap_time = ap_status;
		

	}
	
	public Appointment()
	{
		
	}

	public int getp_id() {
		return p_id;
	}

	public void setp_id(int p_id) {
		this.p_id = p_id;
	}

	public String getp_aname() {
		return p_aname;
	}

	public void setP_Name(String p_aname) {
		this.p_aname = p_aname;
	}
	public String getP_amid() {
		return p_amid;
	}

	public void setp_amid(String p_amid) {
		this.p_amid = p_amid;
	}
	public String getcity() {
		return city;
	}
	public void setcity(String city) {
		this.city = city;
	}
	public String getgender() {
		return gender;
	}
	public void setgender(String gender) {
		this.gender = gender;
	}

	public int getd_id() {
		return d_id;
	}

	public void setd_id(int d_id) {
		this.d_id = d_id;
	}
	public int getap_id() {
		return ap_id;
	}

	public void setap_id(int ap_id) {
		this.ap_id = ap_id;
	}
	
	public Date getap_date() {
		return ap_date;
	}

	public void setap_date(Date ap_date ) {
		this.ap_date =ap_date ;
	}	
	public String getap_time() {
		return ap_time;
	}

	public void setap_time(String ap_time) {
		this.ap_time = ap_time;
	}	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}

